-----------------------------------------------------------------------------------
Project: OpenGTS - Open GPS Tracking System
URL    : http://www.opengts.org
File   : src/org/opengts/war/track/page/devcmd/README.txt
-----------------------------------------------------------------------------------

Note:
Some, or all, of the device communication servers referenced by these property pages 
included in this directory might not be available in this release.
