package vn.bakastar.db;

public interface SQLConstants {

	public static final String SCHEMA_NAME = "[$SCHEMA_NAME$]";

	public static final String TABLE_NAME = "[$TABLE_NAME$]";
}
